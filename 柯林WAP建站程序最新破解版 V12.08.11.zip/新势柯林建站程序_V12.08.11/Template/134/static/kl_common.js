var KLCOMMON = (function(win, api) {

    //构建对象
    var build = {
        api: {}, //柯林程序API接口
        
        extend: extend, //属性覆盖
        ajax : ajax,
        setbind: setbind, //事件绑定
        delBind: delBind, //事件解除
        
        setCookie: setCookie, //设置cookie
        getCookie: getCookie, //获取cookie
        delCookie: delCookie, //删除cookie
    
    };
    extend(build.api, api);
    
    
    function extend(o1, o2) {
        for (attr in o2) {
            o1[attr] = o2[attr];
        }
    }
    
    function setbind(obj, type, fn) {
        if (obj.addEventListener) {
            obj.addEventListener(type, fn, false);
        } else if (obj.attachEvent) {
            obj.attachEvent('on' + type, fn);
        } else {
            obj['on' + type] = fn;
        }
    }
    
    function delBind(obj, type, fn) {
        if (typeof obj.removeEventListener != 'undefined') {
            obj.removeEventListener(type, fn, false);
        } else if (typeof obj.detachEvent != 'undefined') {
            for (var i in obj.events[type]) {
                if (obj.events[type][i] == fn)
                    delete obj.events[type][i];
            }
        }
    }
    
    function setCookie(name, value) {
        var Days = 30;
        var exp = new Date();
        exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
        document.cookie = name + '=' + escape(value) + ';expires=' + exp.toGMTString() + ';path=/';
    }
    
    function getCookie(name) {
        var arr, reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)');
        if (arr = document.cookie.match(reg))
            return unescape(arr[2]);
        else
            return null;
    }
    
    function delCookie(name) 
    {
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval = getCookie(name);
        if (cval != null)
            document.cookie = name + '=' + cval + ';expires=' + exp.toGMTString();
    }
    
    function ajax(setting) {
        var config = {
            type: 'GET', /*提交类型*/
            path: '/', /*请求地址*/
            query: {}, /*参数*/
            fnLoad: function(sHtml) {
            }, /*请求成功后执行函数，传入返回的数据*/
            fnErr: function() {
            } /*请求失败后执行*/
        };
        
        var oAjax = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var query = '';
        var aKeyVal = [];
        extend(config, setting);
        
        for (attr in config.query) {
            config.query.hasOwnProperty(attr) && aKeyVal.push(attr + '=' + encodeURI(config.query[attr] + ''));
        }
        query = aKeyVal.join('&');
        if (config.type == 'get' || config.type == 'GET') {
            query = config.path + '?' + query + '&' + new Date().getTime();
            oAjax.open(config.type, query, true);
            oAjax.send();
        } else {
            oAjax.open('post', config.path, true);
            oAjax.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            oAjax.send(query);
        }
        
        oAjax.onreadystatechange = fnReadystatechange;
		
        function fnReadystatechange() {
            if (oAjax.readyState == 4) {
                if (oAjax.status == 200) {
                    config.fnLoad(oAjax.responseText);
                } else {
                    config.fnErr();
                }
            }
        }
    }

    //返回对象
    return build;
})(window, KELINKAPI);
