/*
项目建立：2015-07-14
最后更改时间：2015-07-14
版权：广州市联速科技
官网：http://kelink.com
说明：本插件基于柯林程序kl_common.js主程序开发，主要用于分页
*/
function KLAjaxPage($, obj, iCount, iPage, reqTypeVaule, url, reqType) {
    
    var path = url.split('?')[0]; /*获得文件路径*/
    var query = urlTurnQuery(url.split('?')[1], reqType, reqTypeVaule); /*获得请求参数*/
    if (parseInt(obj.reqType) > iCount) {
        return;
    } else {
		if(!obj.classNames){
			obj.classNames = obj.className;
		}
		obj.className += ' load';
        obj.innerHTML = '获取数据中...';
    }
    if (obj.title != 'true') {
        obj.title = 'true';
        $.ajax({
            type: 'GET',
            path: path,
            query: query,
            fnLoad: function(sHtml) { /*请求成功，并且返回数据*/
				try{
                var re = /<!--listS-->([\s\S]*?)<!--listE-->/;
                var sContent = sHtml.match(re)[1];
                var oPage = document.getElementById('kl-ajax-page-box');
                
                if (oPage.tagName.toLowerCase() == 'ul') {
                    var reLi = /<li[^>]*?>([\s\S]*?)<\/li>/g;
                    var aLi = sContent.match(reLi);
                    
                    for (var i = 0; i < aLi.length; i++) {
                        var oLi = document.createElement('li');
                        oLi.innerHTML = aLi[i].replace(reLi, '$1');
                        oPage.appendChild(oLi);
                    }
                
                } else {
                    oPage.innerHTML += sContent;
                }
				
                obj.title = 'false';
                obj.reqType = query[reqType] + 1;
                if (parseInt(obj.reqType) > iCount) {
                    obj.innerHTML = '恭喜你！居然到底了！';
                } else {
                    obj.innerHTML = '获取更多数据';
                }
				}catch (e){
					obj.title = 'false';
					obj.innerHTML = '程序错误，请联系站长！';
				}
				
				obj.className = obj.classNames;
            },
            fnErr: function() { /*请求失败*/
                obj.title = 'false';
                obj.innerHTML = '网络错误';
				obj.className = obj.classNames;
            }
        });
    }
    
    function urlTurnQuery(url, reqType, reqTypeVaule) { /*将url转化成query*/
        var json = {};
        var arr = url.split('&');
        
        for (var i = 0; i < arr.length; i++) {
            var name = arr[i].split('=')[0];
            var value = arr[i].split('=')[1];
            json[name] = value;
        }
        if (obj.reqType) {
            json[reqType] = parseInt(obj.reqType);
        } else {
            json[reqType] = parseInt(reqTypeVaule) + 1;
        }
        return json;
    }

}
