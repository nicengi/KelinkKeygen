if (getCookie('skinColor')) {
	var sCss = getCookie('skinColor');
	var oStyle = document.createElement('style');
	oStyle.id = 'skin-style';
	oStyle.innerHTML = sCss;
	kq('head').$[0].appendChild(oStyle);
}

function kq(v) {


	function Kq(v) {
		this.$ = [];
		switch (typeof v) {
		case 'string':
			this.$ = document.querySelectorAll(v);
			break;
		case 'function':
			bind(window, 'load', v);
			break;
		case 'object':
			this.$.push(v);
			break;
		}
	}
	Kq.prototype.fn = function (fn) {
		if (fn) fn(this.$)
	}
	Kq.prototype.for = function (fn) {
		for (var i = 0; i < this.$.length; i++) {
			fn(this.$[i], i);
		}
	}
	Kq.prototype.bind = function (type, fn) {
		this.for(function (obj, i) {
			var arr = type.split(',');
			for (var j = 0; j < arr.length; j++) {
				bind(obj, arr[j], fn);
			}
		});
	}
	Kq.prototype.css = function (attr, v) {
		if (arguments.length == 2) {
			this.for(function (obj) {
				obj.style[attr] = v;
			});
		} else {
			if (typeof attr == "string") {
				return getStyle(this.element[0], attr);
			} else {
				this.for(function (obj, i) {
					var k = "";

					for (k in attr) {
						obj.style[k] = attr[k];
					}
				});
			}
		}
		return this;
	}

	function bind(obj, type, fn) {
		if (obj.addEventListener) {
			obj.addEventListener(type, fn, false);
		} else if (obj.attachEvent) {
			if (!obj.events)
				obj.events = {};
			if (!this.EventId)
				this.EventId = 1;
			if (!obj.events[type]) {
				obj.events[type] = [];
				if (!obj["on" + type])
					obj.events[type][0] = fn;
			} else {
				for (var i in obj.events[type]) {
					if (obj.events[type][i] == fn) {
						return false;
					}
				}
				obj.events[type][this.EventId++] = fn;
			}

			obj["on" + type] = function () {
				var e = window.event;
				for (var i in obj.events[type]) {
					obj.events[type][i].call(this, e);
				}
			}
		}
	}

	function removeBind(obj, type, fn) {
		if (typeof obj.removeEventListener != "undefined") {
			obj.removeEventListener(type, fn, false);
		} else if (typeof obj.detachEvent != "undefined") {
			for (var i in obj.events[type]) {
				if (obj.events[type][i] == fn)
					delete obj.events[type][i];
			}
		}
	}
	return new Kq(v);
}


kq(function () {
	//左边头部弹出方形菜单
	var oShowBox = document.createElement("div");
	var hideNav = kq('#hide-nav').$[0];
	oShowBox.id = 'showBox';
	kq('body').fn(function (obj) {
		obj[0].appendChild(oShowBox);
	});
	kq('.areaimg').bind('click', function () {

		if (hideNav.className == 'hide') {
			hideNav.className = 'show';
			oShowBox.style.display = 'block';
		} else {
			hideNav.className = 'hide';
		}
	});
	kq('#showBox').bind('click', function () {
		hideNav.className = 'hide';
		this.style.display = 'none';
		if (kq('#header-skin').$[0]) kq('#header-skin').$[0].className = 'hide';

	});
	//	中间部分切换皮肤
	var sColor = config.skin;
	var aColor = sColor.split(',');
	var oSkinDiv = document.createElement('div');
	var clientWidth = document.documentElement.clientWidth;
	oSkinDiv.id = 'header-skin';
	oSkinDiv.className = 'hide';
	kq('body').$[0].appendChild(oSkinDiv);
	oSkinDiv.style.height = aColor.length * 20 + 'px';
	for (var i = 0; i < aColor.length; i++) {
		oSkinDiv.innerHTML += '<i style="background:' + aColor[i] + '" onclick="setCookieSkin(this)"></i>';
	}

	kq('#header-tit').bind('click', function () {
		oShowBox.style.display = 'block';
		kq('#header-skin').$[0].className = 'show';
	});
});

function setCookieSkin(obj) {

	var sHtml = '.skin {\
			background-color: #4496b4;\
	}';
	sHtml = sHtml.replace(/\s/g, '');
	sHtml = sHtml.replace(/\#(.*?)\;/g, obj.style.backgroundColor + '!important;');
	if (document.getElementById('skin-style')) {

		kq('#skin-style').$[0].innerHTML = sHtml;

	} else {

		var oStyle = document.createElement('style');
		oStyle.id = 'skin-style';

		oStyle.innerHTML = sHtml;
		kq('head').$[0].appendChild(oStyle);

	}

	setCookie('skinColor', sHtml);

}

function ajax(sty, url, fnTrue, fnFalse) {
	var oAjax = null;

	if (window.XMLHttpRequest) {
		oAjax = new XMLHttpRequest();
	} else {
		oAjax = new ActiveXObject("Microsoft.XMLHTTP");
	}
	switch (sty) {
	case "post":
		var arr = url.split("?");
		oAjax.open(sty, arr[0], true);
		oAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		if (arr.length < 2) {
			oAjax.send(arr[1]);
		} else {
			var arrUrl = "";
			for (var i = 1; i < arr.length; i++) {
				arrUrl += "?" + arr[i];
			}
			oAjax.send(arrUrl.substring(1));
		}
		break;
	case "get":
		url += "?" + new Date().getTime();
		oAjax.open(sty, url, true);
		oAjax.send();
		break;
	}
	oAjax.onreadystatechange = function () {
		if (oAjax.readyState == 4) {
			if (oAjax.status == 200) {
				fnTrue(oAjax.responseText);
			} else {
				if (fnFalse) {
					fnFalse();
				}
			}
		}
	}
}

function setCookie(name, value) {
	var Days = 30;
	var exp = new Date();
	exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString()+ ";path=/";
}

function getCookie(name) {
	var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
	if (arr = document.cookie.match(reg)) return unescape(arr[2]);
	else return null;
}

function log(v) {
	console.log(v);
}