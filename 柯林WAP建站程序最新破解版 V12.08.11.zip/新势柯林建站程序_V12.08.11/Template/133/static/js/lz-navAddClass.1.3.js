/*
	声明：保留头部版权的情况下，可以自由的使用，可以作为商业用途
	开发者：狼族小狈
	官网：http://kelink.com
	版本：1.2
	最后修改日期：2015.07.01
*/
(function(win) {
    if (!win.applicationCache) {
        return;
        /*浏览器若是不支持html5，退出程序，直接返回*/
    }
    var aEnt = document.querySelectorAll('[data-lz-navaddclass]');
    
    
    for (var i = 0; i < aEnt.length; i++) {
        var config = {
            query: 'classid|action',
            //对比参数不同
            addClassName: 'on',
            //添加的class名称
            errChild: 0 //没有找到时，设置哪个添加class
        };
        var seting = JSON.parse(aEnt[i].dataset.lzNavaddclass);
        for (attr in seting) {
            //属性覆盖，优先使用用户配置的
            config[attr] = seting[attr];
        
        }
        lzNavAddClass(aEnt[i], config);
    
    }



}
)(window);

function lzNavAddClass(obj, config) {
    
    
    
    var obj = (typeof obj == 'string') ? document.getElementById(obj) : obj;
    
    init(obj, config);
    function init(obj, config) {
        //初始化程序
        var aQuery = config.query.split('|');
        var aTag = obj.querySelectorAll('a');
        
        for (var i = 0; i < aQuery.length; i++) {
            var winHref = window.location.href;
            var re = new RegExp(aQuery[i] + '=[^\&]+');
            var reHref = new RegExp(winHref.match(re));
            for (var j = 0; j < aTag.length; j++) {
                var url = aTag[j].href;
                if (reHref && reHref.test(url)) {
                    addClass(aTag[j], config.addClassName);
                    return;
                }
                if (aQuery[i] == 'classid' && KELINKAPI.nv && fnNv(url)) {
                    addClass(aTag[j], config.addClassName);
                    return;
                }
            }
        }
        //如果都找不到，就给用户设置的第几个添加class
        addClass(aTag[config.errChild], config.addClassName);
    
    }
    
    function addClass(obj, sClassName) {
        //添加class
        obj.className += ' ' + sClassName;
        if (obj.parentNode.localName == 'li') {
            //如果连接的父级是li标签，也添加class
            obj.parentNode.className += ' ' + sClassName;
        }
    }
    
    function fnNv(url) {
        var aNv = KELINKAPI.nv;
        for (var i = 1; i < aNv.length; i++) {
            var re = RegExp('classid=' + aNv[i].classid);
            if (re.test(url)) {
                return true;
            }
        }
        return false;
    }

}
