// JavaScript Document
(function (){
	if(!window.KELINKAPI){
		return;;
	}
	
	$(function (){
		$('#kl-guessbookadmin_wapadd').find('select').eq(0).attr('value', '1').css('display','none');

	});
})();