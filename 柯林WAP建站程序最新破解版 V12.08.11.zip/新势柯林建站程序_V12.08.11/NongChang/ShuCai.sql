INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',1,1,2,0,30,1,11,1,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'���ܲ�',2,1,3,0,30,2,13,2,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'��ײ�',3,1,4,0,30,3,15,3,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'�ƹ�',4,1,5,0,35,4,16,4,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',5,1,5,0,37,5,20,5,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',6,1,6,0,40,6,22,6,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'�Ϲ�',7,1,7,0,43,7,27,7,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'������',8,1,8,0,40,9,28,8,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',9,1,9,0,35,8,30,9,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'���տ�',10,1,10,0,40,10,31,10,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'��ݮ',11,2,8,3,50,7,40,11,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',12,2,9,4,55,8,50,12,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',13,2,10,5,65,10,70,13,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',14,2,11,5,70,9,86,14,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'⨺���',15,2,11,5,85,11,90,15,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',16,2,12,6,80,12,95,16,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'â��',17,2,13,7,85,10,107,17,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'«��',18,2,15,7,70,13,120,18,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'��õ��',19,1,2,0,6,1,30,1,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'��õ��',20,1,4,0,8,3,40,4,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'��õ��',21,1,6,0,12,5,63,6,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����ٺ�',22,1,8,0,17,7,100,10,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'��ɫ����',23,2,48,1,10,100000,500,1,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'ƻ��',24,2,14,8,87,9,200,19,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'����',25,2,15,8,90,8,220,20,{$siteid$})
GO
INSERT INTO [Farm_ShuCai]([ID],[ShuCaiMingChen],[SuoYing],[ZhongZhiJiDu],[ChengShuShiJian],[ZaiCiChengShu],[YuJiChanLiang],[ShuCaiShouJia],[ShouHuoJingYan],[ZhongZhiDenJi],[siteid])VALUES({$id$},N'ʯ��',26,3,12,5,130,10,250,21,{$siteid$})