INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美沙滩',N'background/sysimg/1.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'蓝色星河',N'background/sysimg/2.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'城市夕阳',N'background/sysimg/3.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'魔幻山河',N'background/sysimg/4.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'向日葵',N'background/sysimg/5.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'冰激凌',N'background/sysimg/6.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'草原夕阳',N'background/sysimg/7.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'刺客信条',N'background/sysimg/8.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'简约',N'background/sysimg/9.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'科幻暗夜',N'background/sysimg/10.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'科幻高能',N'background/sysimg/11.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'落日余晖',N'background/sysimg/12.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'旅行心情',N'background/sysimg/13.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'那些年',N'background/sysimg/14.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'秋风落叶',N'background/sysimg/15.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'时光记忆',N'background/sysimg/16.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'往昔回忆',N'background/sysimg/17.jpg',500,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美V1',N'background/sysimg/18.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v2',N'background/sysimg/19.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v3',N'background/sysimg/20.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v4',N'background/sysimg/21.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v5',N'background/sysimg/22.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v6',N'background/sysimg/23.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v7',N'background/sysimg/24.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'唯美v8',N'background/sysimg/25.jpg',400,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'小盒子V1',N'background/sysimg/26.jpg',300,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'小盒子v2',N'background/sysimg/27.jpg',300,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

INSERT INTO [wap_background]([siteid],[bgname],[bgimage],[needmoney],[addtime],[makeid],[types],[issystem])VALUES($siteid$,N'小盒子v3',N'background/sysimg/28.jpg',300,N'2015-01-08 18:18:18',$makeid$,0,1)
GO

